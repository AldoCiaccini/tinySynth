var searchData=
[
  ['naivesaw',['NaiveSaw',['../classstk_1_1tiny_synth_l_f_o_1_1_naive_saw.html',1,'stk::tinySynthLFO']]],
  ['naivesquare',['NaiveSquare',['../classstk_1_1tiny_synth_l_f_o_1_1_naive_square.html',1,'stk::tinySynthLFO']]]
];
