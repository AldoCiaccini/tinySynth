var searchData=
[
  ['acceptsmidi',['acceptsMidi',['../classtiny_synth_audio_processor.html#ab434ca594e0cb30a9edd21455e11e108',1,'tinySynthAudioProcessor']]],
  ['appliestochannel',['appliesToChannel',['../classtiny_synth_sound.html#a226735a0fc4bf6c6c9848d2529e9ad9a',1,'tinySynthSound']]]
];
