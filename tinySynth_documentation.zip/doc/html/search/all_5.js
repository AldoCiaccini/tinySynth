var searchData=
[
  ['isinputchannelstereopair',['isInputChannelStereoPair',['../classtiny_synth_audio_processor.html#ac8c953189fdaac4b9ee54140f0824667',1,'tinySynthAudioProcessor']]],
  ['isoutputchannelstereopair',['isOutputChannelStereoPair',['../classtiny_synth_audio_processor.html#ac36e9f08b9401c9f745ce3200c44f30d',1,'tinySynthAudioProcessor']]]
];
